'use strict';

module.exports.d100 = function () {
  return Math.floor(Math.random() * 100) + 1;
};
